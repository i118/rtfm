This is the proBlue theme for Sphinx.

http://www.kellycreativetech.com/Blog/entry/ProBlue_Sphinx_Theme/

You can install it by putting it in your docs directory (next to _static)
then you can set in your conf.py

    html_theme = 'proBlue'
    html_theme_path = ["."]